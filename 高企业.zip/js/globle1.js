$(function(){
	//头部尾部引进
	$(".header_content").load("common/header1.html");
	$(".footer_content").load("common/footer.html");
	

})