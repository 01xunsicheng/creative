$(function(){
	//头部尾部引进
	$(".header_content").load("common/header.html");
	$(".footer_content").load("common/footer.html");
})